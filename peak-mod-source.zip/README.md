# PEAK: Scout Survival — Fabric 1.21.1

A substantial PEAK-inspired expedition mod for Minecraft Java 1.21.1 (Fabric, Java 21). This is an original fan implementation, not a port of PEAK's copyrighted game files or artwork.

## Expedition flow

1. On the first join to a world, the player is moved to a generated BingBong Airlines-style airport terminal.
2. A Scout Passport is placed in the inventory. Using it displays passport information; full cosmetic/appearance editing is not implemented.
3. Walk along the runway and enter the block-built aircraft. The glowing gold boarding tile inside the plane starts the expedition.
4. Boarding generates the Shore crash site about 1,200 blocks away and teleports the player beside the wreckage.
5. Search supply barrels, cook food at the crash fire, and climb through the route. Region names appear when entering a new section.
6. The route ends at a snowy summit with a beacon.

The generated route includes Shore, one of Tropics/Roots, one of Alpine/Mesa, one of Caldera/Gloom, one of The Kiln/The Citadel, and The Peak. The alternative biome in each pair is selected from the world seed. Terrain is a hand-built, block-based approximation with cliffs, raised ledges, themed palettes and hazards; it is not PEAK's original procedural terrain generator.

## Core mechanics

- Wall climbing while holding the configurable Grab Wall key and moving upward.
- Shift Lunge while climbing: a short vertical boost that consumes stamina.
- Main stamina and bonus stamina; climbing and sprinting spend stamina, food can grant bonus stamina, and running out while climbing causes a slide.
- Hunger, carried equipment weight, fall injury, poison, cold, heat, drowsiness, thorns and spores.
- Cold and heat offset each other. Environmental temperature and hazards can add status values.
- Food, drinks, medical supplies, lantern, guidebook, piton, rope spool, anti-rope spool and Pirate's Compass.
- Pitons act as one-scout rest anchors: interact to attach/detach, then recover stamina while staying close.
- Rope spools deploy climbable rope; anti-rope spools deploy upward-floating rope.
- Campfire cooking recipes for the included foods. Cooked foods generally restore more hunger and bonus stamina.
- A compact expedition HUD and Russian/English translations.

## Controls

- Grab Wall: Left Alt by default (rebindable in Options → Controls). Minecraft reserves the left mouse button for block attack, so this adaptation uses a separate key rather than breaking normal mining.
- Lunge: Left Shift while climbing.
- Interact with boarding tile / piton: normal Minecraft Use key (E by default).
- Use food and equipment: normal Minecraft item-use key.

## Deliberate omissions / differences

The main airport → aircraft → crash site → climb → summit loop is present, but this is not a one-to-one remake. Still omitted or simplified: passport cosmetic editor and scout avatar customization; exact takeoff/crash cinematic; the full original character hand-grab and teammate rescue animation; voice chat, emotes and ping wheel; the complete enemy roster and their AI; the complete rare/mystical item catalogue and secret routes; exact original 3D models, animations, sound design, daily map rotation and physics. Several hazards are represented by Minecraft blocks rather than bespoke entities. Original pixel-art item icons are included; they are newly drawn and not extracted from PEAK.

## Build locally

Requires Java 21 and Gradle 8.11.1:

```bash
gradle clean build
```

The mod JAR is written to `build/libs/`.

## GitHub Actions build

1. Put `peak-mod-source.zip` in the root of your GitHub repository.
2. Put the separate workflow file at `.github/workflows/build.yml`.
3. Push both files or run the workflow manually from the Actions tab.
4. Download the `peak-fabric-1.21.1` artifact. The mod JAR is inside.

The workflow extracts the ZIP and builds it with Java 21 and Gradle 8.11.1.

## Verification status

Resource JSON files and ZIP structure are checked. This environment does not have Gradle installed and cannot download it, so Java compilation and an in-game launch have not been verified. Treat the first GitHub Actions build as the compile check before installing the JAR in a main world.
