package com.peakmod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record PeakControlPayload(boolean climbing, boolean lunge) implements CustomPayload {
    public static final Id<PeakControlPayload> ID = new Id<>(Identifier.of(PeakMod.MOD_ID, "control"));
    public static final PacketCodec<RegistryByteBuf, PeakControlPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.BOOL, PeakControlPayload::climbing,
                    PacketCodecs.BOOL, PeakControlPayload::lunge, PeakControlPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
