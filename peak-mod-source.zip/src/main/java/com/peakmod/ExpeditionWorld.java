package com.peakmod;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import java.util.Random;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.player.PlayerEntity;

/** Procedurally assembles an airport lobby and a six-region expedition route. */
public final class ExpeditionWorld {
 private static final Map<UUID, BlockPos> RUN_ORIGINS = new ConcurrentHashMap<>();
 private static final Map<UUID, String[]> RUN_REGIONS = new ConcurrentHashMap<>();
 private ExpeditionWorld() {}
 public static void buildAirport(ServerPlayerEntity p){
  ServerWorld w=p.getServerWorld(); BlockPos s=w.getSpawnPos(); int x=s.getX()+48,z=s.getZ()+48;
  int y=Math.max(80,w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,x,z)+2); BlockPos b=new BlockPos(x,y,z);
  buildAirportAt(w,b); p.requestTeleport(x+.5,y+1,z+2.5); p.sendMessage(Text.translatable("message.peakmod.airport_arrival"),false);
 }
 private static void buildAirportAt(ServerWorld w,BlockPos b){
  fill(w,b.add(-16,0,-12),b.add(16,0,12),Blocks.SMOOTH_QUARTZ);
  fill(w,b.add(-16,1,-12),b.add(-16,7,12),Blocks.WHITE_CONCRETE); fill(w,b.add(16,1,-12),b.add(16,7,12),Blocks.WHITE_CONCRETE);
  fill(w,b.add(-15,1,-12),b.add(15,7,-12),Blocks.WHITE_CONCRETE); fill(w,b.add(-15,1,12),b.add(15,7,12),Blocks.WHITE_CONCRETE);
  fill(w,b.add(-14,1,-11),b.add(14,4,-11),Blocks.GLASS); fill(w,b.add(-14,1,11),b.add(14,4,11),Blocks.GLASS);
  fill(w,b.add(-15,5,-11),b.add(15,5,11),Blocks.LIGHT_GRAY_CONCRETE);
  fill(w,b.add(-10,1,-7),b.add(-4,2,-6),Blocks.POLISHED_ANDESITE); fill(w,b.add(4,1,-7),b.add(10,2,-6),Blocks.POLISHED_ANDESITE);
  for(int sx:new int[]{-10,-7,-4,4,7,10}){w.setBlockState(b.add(sx,1,4),Blocks.SPRUCE_STAIRS.getDefaultState(),3);w.setBlockState(b.add(sx,1,5),Blocks.SPRUCE_STAIRS.getDefaultState(),3);}
  w.setBlockState(b.add(0,1,-8),Blocks.SEA_LANTERN.getDefaultState(),3); w.setBlockState(b.add(-12,1,-8),Blocks.BELL.getDefaultState(),3);
  // Runway and walk-in aircraft.
  fill(w,b.add(18,0,-5),b.add(62,0,5),Blocks.GRAY_CONCRETE);
  fill(w,b.add(28,1,-3),b.add(53,1,3),Blocks.IRON_BLOCK);
  fill(w,b.add(28,2,-3),b.add(53,4,-3),Blocks.LIGHT_GRAY_CONCRETE); fill(w,b.add(28,2,3),b.add(53,4,3),Blocks.LIGHT_GRAY_CONCRETE);
  fill(w,b.add(53,2,-2),b.add(53,4,2),Blocks.IRON_BLOCK); fill(w,b.add(29,4,-2),b.add(52,4,2),Blocks.IRON_BLOCK);
  for(int zz=-2;zz<=2;zz++) for(int xx:new int[]{30,36,42,48}) w.setBlockState(b.add(xx,2,zz),Blocks.GLASS.getDefaultState(),3);
  fill(w,b.add(36,1,-12),b.add(42,1,12),Blocks.IRON_BLOCK); fill(w,b.add(49,1,-7),b.add(53,1,7),Blocks.IRON_BLOCK);
  w.setBlockState(b.add(32,2,0),PeakMod.BOARDING_BLOCK.getDefaultState(),3);
  w.setBlockState(b.add(0,1,0),Blocks.SMOOTH_QUARTZ.getDefaultState(),3); w.setBlockState(b.add(0,2,0),Blocks.LANTERN.getDefaultState(),3);
 }
 public static BlockPos buildCrashSite(ServerWorld w,BlockPos airport, ServerPlayerEntity player){
  BlockPos o=new BlockPos(airport.getX()+1200,Math.max(88,airport.getY()),airport.getZ()+1200); int x=o.getX(),y=o.getY(),z=o.getZ();
  // Shore, sand, waterline and broken plane.
  fill(w,o.add(-28,-2,-20),o.add(28,0,58),Blocks.SAND); fill(w,o.add(-28,-3,-20),o.add(28,-3,58),Blocks.SANDSTONE);
  fill(w,o.add(-31,-2,-20),o.add(-29,-1,58),Blocks.WATER); fill(w,o.add(29,-2,-20),o.add(31,-1,58),Blocks.WATER);
  fill(w,o.add(-8,1,12),o.add(8,1,24),Blocks.IRON_BLOCK); fill(w,o.add(-8,2,12),o.add(-8,4,24),Blocks.LIGHT_GRAY_CONCRETE);
  fill(w,o.add(8,2,12),o.add(8,4,24),Blocks.LIGHT_GRAY_CONCRETE); fill(w,o.add(-8,5,12),o.add(-3,5,17),Blocks.IRON_BLOCK);
  fill(w,o.add(3,5,20),o.add(8,5,24),Blocks.IRON_BLOCK); w.setBlockState(o.add(0,1,18),Blocks.CAMPFIRE.getDefaultState(),3);
  crate(w,o.add(-11,1,15)); crate(w,o.add(11,1,21));
  buildStage(w,x,y,z+58,Blocks.STONE,Blocks.COBBLESTONE,Blocks.SANDSTONE,0);
  Random r=new Random(w.getSeed()^x^z); boolean roots=r.nextBoolean(),mesa=r.nextBoolean(),gloom=r.nextBoolean(),citadel=r.nextBoolean();
  RUN_ORIGINS.put(player.getUuid(),o);
  RUN_REGIONS.put(player.getUuid(),new String[]{"Shore",roots?"Roots":"Tropics",mesa?"Mesa":"Alpine",gloom?"Gloom":"Caldera",citadel?"The Citadel":"The Kiln","The Peak"});
  buildStage(w,x,y+10,z+112,roots?Blocks.MYCELIUM:Blocks.GRASS_BLOCK,roots?Blocks.MUSHROOM_STEM:Blocks.JUNGLE_LOG,roots?Blocks.MOSS_BLOCK:Blocks.MOSSY_COBBLESTONE,1);
  buildStage(w,x,y+22,z+170,mesa?Blocks.RED_SAND:Blocks.SNOW_BLOCK,mesa?Blocks.SANDSTONE:Blocks.PACKED_ICE,mesa?Blocks.TERRACOTTA:Blocks.BLUE_ICE,2);
  buildStage(w,x,y+34,z+228,gloom?Blocks.SOUL_SOIL:Blocks.BASALT,gloom?Blocks.DEEPSLATE:Blocks.BLACKSTONE,gloom?Blocks.SOUL_SAND:Blocks.MAGMA_BLOCK,3);
  buildStage(w,x,y+48,z+286,citadel?Blocks.DEEPSLATE_BRICKS:Blocks.BLACKSTONE,citadel?Blocks.POLISHED_DEEPSLATE:Blocks.BASALT,citadel?Blocks.IRON_BARS:Blocks.MAGMA_BLOCK,4);
  fill(w,o.add(-10,62,340),o.add(10,62,360),Blocks.SNOW_BLOCK); fill(w,o.add(-5,63,345),o.add(5,63,355),Blocks.STONE);
  w.setBlockState(o.add(0,64,350),Blocks.BEACON.getDefaultState(),3); w.setBlockState(o.add(0,63,350),Blocks.IRON_BLOCK.getDefaultState(),3);
  return o.add(0,1,3);
 }

 public static String regionFor(PlayerEntity player) {
  BlockPos origin=RUN_ORIGINS.get(player.getUuid()); String[] names=RUN_REGIONS.get(player.getUuid());
  if(origin==null||names==null) return "";
  int dz=player.getBlockZ()-origin.getZ();
  if(dz<58) return names[0]; if(dz<112) return names[1]; if(dz<170) return names[2];
  if(dz<228) return names[3]; if(dz<286) return names[4]; return names[5];
 }
 public static void clearRun(UUID id){RUN_ORIGINS.remove(id);RUN_REGIONS.remove(id);}

 private static void buildStage(ServerWorld w,int x,int baseY,int startZ,Block ground,Block wall,Block ledge,int stage){
  fill(w,new BlockPos(x-22,baseY,startZ),new BlockPos(x+22,baseY,startZ+52),ground);
  fill(w,new BlockPos(x-22,baseY-1,startZ),new BlockPos(x+22,baseY-1,startZ+52),wall);
  for(int i=0;i<5;i++){int zz=startZ+10+i*9,yy=baseY+2+i*2;fill(w,new BlockPos(x-8,yy,zz),new BlockPos(x+8,yy,zz+4),ledge);}
  fill(w,new BlockPos(x-20,baseY+1,startZ+50),new BlockPos(x+20,baseY+13,startZ+52),wall);
  for(int i=0;i<7;i++){int yy=baseY+2+i*2,xx=x+(i%2==0?-10:4);fill(w,new BlockPos(xx,yy,startZ+49),new BlockPos(xx+6,yy,startZ+50),ledge);}
  if(stage==1){for(int i=0;i<8;i++){int xx=x-16+(i%4)*10,zz=startZ+8+(i/4)*25;fill(w,new BlockPos(xx,baseY+1,zz),new BlockPos(xx,baseY+5,zz),Blocks.JUNGLE_LOG);w.setBlockState(new BlockPos(xx,baseY+6,zz),Blocks.JUNGLE_LEAVES.getDefaultState(),3);}for(int i=0;i<4;i++)w.setBlockState(new BlockPos(x-12+i*8,baseY+1,startZ+35),Blocks.SWEET_BERRY_BUSH.getDefaultState(),3);}
  if(stage==2){for(int i=0;i<6;i++)w.setBlockState(new BlockPos(x-15+i*6,baseY+1,startZ+18),ground==Blocks.RED_SAND?Blocks.CACTUS.getDefaultState():Blocks.POWDER_SNOW.getDefaultState(),3);}
  if(stage==3)fill(w,new BlockPos(x-4,baseY+1,startZ+12),new BlockPos(x+4,baseY+1,startZ+35),Blocks.MAGMA_BLOCK);
  if(stage==4)for(int i=0;i<5;i++)w.setBlockState(new BlockPos(x-14+i*7,baseY+1,startZ+20),Blocks.CHAIN.getDefaultState(),3);
  crate(w,new BlockPos(x+13,baseY+1,startZ+7));
 }
 private static void crate(ServerWorld w,BlockPos p){
  w.setBlockState(p,Blocks.BARREL.getDefaultState(),3); BlockEntity be=w.getBlockEntity(p);
  if(be instanceof Inventory inv){ItemStack[] a={new ItemStack(PeakMod.TRAIL_MIX,2),new ItemStack(PeakMod.BANDAGES),new ItemStack(PeakMod.MARSHMALLOW,2),new ItemStack(PeakMod.ROPE_SPOOL),new ItemStack(PeakMod.PITON)};for(int i=0;i<a.length;i++)inv.setStack(i,a[i]);}
 }
 private static void fill(ServerWorld w,BlockPos a,BlockPos b,Block block){
  int x1=Math.min(a.getX(),b.getX()),x2=Math.max(a.getX(),b.getX()),y1=Math.min(a.getY(),b.getY()),y2=Math.max(a.getY(),b.getY()),z1=Math.min(a.getZ(),b.getZ()),z2=Math.max(a.getZ(),b.getZ()); BlockState s=block.getDefaultState();
  for(int x=x1;x<=x2;x++)for(int y=y1;y<=y2;y++)for(int z=z1;z<=z2;z++)w.setBlockState(new BlockPos(x,y,z),s,3);
 }
}
