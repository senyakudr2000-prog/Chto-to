package com.peakmod;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
public final class BoardingBlock extends Block {
 public BoardingBlock(Settings settings){super(settings);}
 @Override protected ActionResult onUse(BlockState state,World world,BlockPos pos,PlayerEntity player,BlockHitResult hit){
  if(world.isClient()) return ActionResult.SUCCESS;
  if(player instanceof ServerPlayerEntity sp && world instanceof ServerWorld sw){
   BlockPos crash=ExpeditionWorld.buildCrashSite(sw,pos,sp);
   PeakMechanics.resetForNewExpedition(sp);
   sp.sendMessage(Text.translatable("message.peakmod.flight_departure"),true);
   sp.requestTeleport(crash.getX()+0.5,crash.getY(),crash.getZ()+0.5);
   return ActionResult.SUCCESS;
  }
  return ActionResult.PASS;
 }
}
