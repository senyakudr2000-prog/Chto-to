package com.peakmod;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
public final class PassportItem extends Item {
 public PassportItem(Settings settings){super(settings);}
 @Override public TypedActionResult<net.minecraft.item.ItemStack> use(World world,PlayerEntity user,Hand hand){
  if(!world.isClient()) user.sendMessage(Text.translatable("message.peakmod.passport_info"),false);
  return TypedActionResult.success(user.getStackInHand(hand),world.isClient());
 }
}
