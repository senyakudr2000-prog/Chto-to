package com.peakmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Deploys a short climbable rope line; the anti-rope variant grows upward. */
public class RopeSpoolItem extends Item {
    private final boolean antiGravity;

    public RopeSpoolItem(Settings settings, boolean antiGravity) {
        super(settings);
        this.antiGravity = antiGravity;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        PlayerEntity player = context.getPlayer();
        BlockPos anchor = context.getBlockPos().offset(context.getSide());
        int placed = 0;
        if (!world.isClient()) {
            for (int i = 0; i < 10; i++) {
                BlockPos ropePos = antiGravity ? anchor.up(i) : anchor.down(i);
                if (!world.getBlockState(ropePos).isAir()) break;
                if (world.setBlockState(ropePos, PeakMod.CLIMBING_ROPE_BLOCK.getDefaultState(), 3)) placed++;
            }
            if (placed > 0) {
                if (player != null && !player.getAbilities().creativeMode) context.getStack().decrement(1);
                world.playSound(null, anchor, SoundEvents.BLOCK_WOOL_PLACE, SoundCategory.BLOCKS, 0.8f, 0.9f);
            }
        }
        return placed > 0 || world.isClient() ? ActionResult.SUCCESS : ActionResult.FAIL;
    }
}
