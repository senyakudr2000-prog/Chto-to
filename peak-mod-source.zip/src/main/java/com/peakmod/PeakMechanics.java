package com.peakmod;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.CampfireBlock;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** PEAK-inspired expedition meters and movement rules. */
public final class PeakMechanics {
    private static final Map<UUID, ScoutStats> SERVER_STATS = new ConcurrentHashMap<>();
    private static final Map<UUID, ScoutStats> CLIENT_STATS = new ConcurrentHashMap<>();
    private static final Map<UUID, Boolean> SERVER_CLIMB_HELD = new ConcurrentHashMap<>();
    private static final Map<UUID, Boolean> CLIENT_CLIMB_HELD = new ConcurrentHashMap<>();
    private static final Map<UUID, BlockPos> PITON_RESTING = new ConcurrentHashMap<>();
    private static final Map<BlockPos, UUID> PITON_OCCUPIED = new ConcurrentHashMap<>();
    private static final float BASE_STAMINA = 100.0f;
    public static final Identifier LUNGE_PACKET = Identifier.of(PeakMod.MOD_ID, "climbing_lunge");
    public static final Identifier CLIMB_PACKET = Identifier.of(PeakMod.MOD_ID, "climb_hold");

    private PeakMechanics() {}

    public static void initialize() {
        ServerTickEvents.END_WORLD_TICK.register(world -> world.getPlayers().forEach(PeakMechanics::tickPlayer));
        ServerPlayNetworking.registerGlobalReceiver(LUNGE_PACKET, (server, player, handler, buf, responseSender) ->
                server.execute(() -> performClimbingLunge(player)));
        ServerPlayNetworking.registerGlobalReceiver(CLIMB_PACKET, (server, player, handler, buf, responseSender) -> {
            boolean held = buf.readBoolean();
            server.execute(() -> SERVER_CLIMB_HELD.put(player.getUuid(), held));
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID uuid = handler.player.getUuid();
            SERVER_CLIMB_HELD.remove(uuid);
            SERVER_STATS.remove(uuid);
            releasePiton(uuid);
            ExpeditionWorld.clearRun(uuid);
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            SERVER_STATS.remove(oldPlayer.getUuid());
            CLIENT_STATS.remove(oldPlayer.getUuid());
            SERVER_CLIMB_HELD.remove(oldPlayer.getUuid());
            CLIENT_CLIMB_HELD.remove(oldPlayer.getUuid());
        });
    }

    public static void tickClientPlayer(PlayerEntity player) { tickPlayer(player); }
    public static void setClientClimbHeld(PlayerEntity player, boolean held) {
        CLIENT_CLIMB_HELD.put(player.getUuid(), held);
    }
    public static void predictClientLunge(PlayerEntity player) {
        ScoutStats s = stats(player);
        if (s.lungeCooldown == 0 && (s.stamina + s.bonusStamina) >= 10.0f) {
            consumeStamina(s, 10.0f);
            s.lungeCooldown = 12;
            s.lungeTicks = 5;
            s.lastStaminaUseTick = s.tick;
        }
    }

    public static boolean togglePitonRest(PlayerEntity player, BlockPos pos) {
        UUID id = player.getUuid();
        BlockPos current = PITON_RESTING.get(id);
        if (current != null) { releasePiton(id); return true; }
        BlockPos anchor = pos.toImmutable();
        UUID owner = PITON_OCCUPIED.get(anchor);
        if (owner != null && !owner.equals(id)) {
            if (!player.getWorld().isClient()) player.sendMessage(Text.translatable("message.peakmod.piton_busy"), true);
            return false;
        }
        PITON_OCCUPIED.put(anchor, id);
        PITON_RESTING.put(id, anchor);
        if (!player.getWorld().isClient()) player.sendMessage(Text.translatable("message.peakmod.piton_resting"), true);
        return true;
    }

    private static void releasePiton(UUID id) {
        BlockPos old = PITON_RESTING.remove(id);
        if (old != null) PITON_OCCUPIED.remove(old, id);
    }

    public static void resetForNewExpedition(PlayerEntity player) {
        UUID id = player.getUuid();
        ScoutStats fresh = new ScoutStats();
        if (player.getWorld().isClient()) CLIENT_STATS.put(id, fresh);
        else SERVER_STATS.put(id, fresh);
    }

    public static ScoutStats stats(PlayerEntity player) {
        Map<UUID, ScoutStats> store = player.getWorld().isClient() ? CLIENT_STATS : SERVER_STATS;
        return store.computeIfAbsent(player.getUuid(), ignored -> new ScoutStats());
    }

    public static float stamina(PlayerEntity player) { return stats(player).stamina; }
    public static float bonusStamina(PlayerEntity player) { return stats(player).bonusStamina; }
    public static float maxStamina(PlayerEntity player) { return Math.max(0.0f, BASE_STAMINA - stats(player).statusTotal()); }
    public static float hunger(PlayerEntity player) { return stats(player).hunger; }
    public static float injury(PlayerEntity player) { return stats(player).injury; }
    public static float poison(PlayerEntity player) { return stats(player).poison; }
    public static float cold(PlayerEntity player) { return stats(player).cold; }
    public static float heat(PlayerEntity player) { return stats(player).heat; }
    public static float drowsy(PlayerEntity player) { return stats(player).drowsy; }
    public static float thorns(PlayerEntity player) { return stats(player).thorns; }
    public static float spores(PlayerEntity player) { return stats(player).spores; }
    public static float weight(PlayerEntity player) { return stats(player).weight; }

    public static void restoreStamina(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.stamina = Math.min(maxStamina(player), s.stamina + amount);
    }

    public static void addBonusStamina(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.bonusStamina = Math.min(100.0f, s.bonusStamina + amount);
    }

    public static void consumeFood(PlayerEntity player, float hungerReduction, float bonus, float injuryHeal,
                                   float poisonHeal, float coldHeal, float heatHeal, float drowsyHeal, float thornsAdd, float sporesHeal) {
        ScoutStats s = stats(player);
        s.hunger = Math.max(0.0f, s.hunger - hungerReduction);
        s.injury = Math.max(0.0f, s.injury - injuryHeal);
        s.poison = Math.max(0.0f, s.poison - poisonHeal);
        s.cold = Math.max(0.0f, s.cold - coldHeal);
        s.heat = Math.max(0.0f, s.heat - heatHeal);
        s.drowsy = Math.max(0.0f, s.drowsy - drowsyHeal);
        s.thorns = Math.min(100.0f, s.thorns + thornsAdd);
        if (thornsAdd > 0.0f) s.thornsDecayDelay = 600;
        s.spores = Math.max(0.0f, s.spores - sporesHeal);
        s.bonusStamina = Math.min(100.0f, s.bonusStamina + bonus);
        s.stamina = Math.min(maxStamina(player), s.stamina);
    }

    public static void scheduleDrowsy(PlayerEntity player, float amount, int delayTicks) {
        ScoutStats s = stats(player);
        s.pendingDrowsy = amount;
        s.pendingDrowsyDelay = delayTicks;
    }

    public static void activateLantern(PlayerEntity player, int ticks) {
        ScoutStats s = stats(player);
        s.lanternTicks = Math.max(s.lanternTicks, ticks);
    }

    public static void grantInfiniteStamina(PlayerEntity player, int ticks) {
        ScoutStats s = stats(player);
        s.infiniteStaminaTicks = Math.max(s.infiniteStaminaTicks, ticks);
    }

    public static void addDrowsy(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.drowsy = Math.min(100.0f, s.drowsy + amount);
        s.drowsyDecayDelay = 200;
    }

    public static void addThorns(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.thorns = Math.min(100.0f, s.thorns + amount);
        s.thornsDecayDelay = 600;
    }

    public static void addSpores(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.spores = Math.min(100.0f, s.spores + amount);
        s.sporesDecayDelay = 900;
    }

    public static void schedulePoison(PlayerEntity player, float amount, int delayTicks) {
        ScoutStats s = stats(player);
        s.pendingPoison = amount;
        s.pendingPoisonDelay = delayTicks;
    }

    public static void addPoison(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.poison = Math.min(100.0f, s.poison + amount);
        s.poisonDecayDelay = 600;
    }

    public static void addCold(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        float cancelled = Math.min(s.heat, amount);
        s.heat -= cancelled;
        s.cold = Math.min(100.0f, s.cold + amount - cancelled);
        s.coldDecayDelay = 100;
    }

    public static void addHeat(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        float cancelled = Math.min(s.cold, amount);
        s.cold -= cancelled;
        s.heat = Math.min(100.0f, s.heat + amount - cancelled);
        s.heatDecayDelay = 160;
    }

    public static void curePoison(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.poison = Math.max(0.0f, s.poison - amount);
        s.pendingPoison = 0.0f;
        s.pendingPoisonDelay = 0;
    }

    public static void cureCold(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.cold = Math.max(0.0f, s.cold - amount);
    }

    public static void cureHeat(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.heat = Math.max(0.0f, s.heat - amount);
    }

    public static void cureDrowsy(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.drowsy = Math.max(0.0f, s.drowsy - amount);
    }

    public static void healInjury(PlayerEntity player, float amount) {
        ScoutStats s = stats(player);
        s.injury = Math.max(0.0f, s.injury - amount);
    }

    public static void cleanse(PlayerEntity player) {
        ScoutStats s = stats(player);
        s.hunger = Math.max(0.0f, s.hunger - 20.0f);
        s.injury = Math.max(0.0f, s.injury - 35.0f);
        s.poison = Math.max(0.0f, s.poison - 35.0f);
        s.cold = Math.max(0.0f, s.cold - 35.0f);
        s.heat = Math.max(0.0f, s.heat - 35.0f);
        s.drowsy = Math.max(0.0f, s.drowsy - 35.0f);
        s.thorns = Math.max(0.0f, s.thorns - 25.0f);
        s.spores = Math.max(0.0f, s.spores - 35.0f);
        s.pendingPoison = 0.0f;
        s.pendingPoisonDelay = 0;
        s.pendingDrowsy = 0.0f;
        s.pendingDrowsyDelay = 0;
    }

    private static void tickPlayer(PlayerEntity player) {
        if (player.isSpectator() || !player.isAlive()) return;
        ScoutStats s = stats(player);
        s.tick++;
        boolean client = player.getWorld().isClient();
        String region = ExpeditionWorld.regionFor(player);
        if (!region.isEmpty() && !region.equals(s.lastRegion)) {
            s.lastRegion = region;
            if (!client) player.sendMessage(Text.literal("— " + region + " —"), true);
        }
        boolean climbHeld = client
                ? CLIENT_CLIMB_HELD.getOrDefault(player.getUuid(), false)
                : SERVER_CLIMB_HELD.getOrDefault(player.getUuid(), false);
        boolean nearCampfire = hasNearbyLitCampfire(player);
        BlockPos piton = PITON_RESTING.get(player.getUuid());
        if (piton != null) {
            if (!player.getWorld().getBlockState(piton).isOf(PeakMod.PITON_BLOCK)
                    || player.squaredDistanceTo(piton.getX()+0.5, piton.getY()+0.5, piton.getZ()+0.5) > 9.0) {
                releasePiton(player.getUuid());
            } else if (!client) {
                s.stamina = Math.min(maxStamina(player), s.stamina + 0.55f);
            }
        }

        if (s.lungeCooldown > 0) s.lungeCooldown--;
        if (s.lungeTicks > 0) s.lungeTicks--;
        if (s.infiniteStaminaTicks > 0) s.infiniteStaminaTicks--;
        if (s.lanternTicks > 0) s.lanternTicks--;

        // The original game lets scouts hold a wall and move upward. In Minecraft the
        // separate Grab key is used to avoid colliding with the vanilla Sneak/Lunge key.
        boolean onRope = isNearRope(player);
        if ((player.horizontalCollision || onRope) && climbHeld && (!player.isOnGround() || onRope)
                && !player.isTouchingWater() && !player.isInLava()) {
            if (s.stamina > 0.0f || s.bonusStamina > 0.0f || s.infiniteStaminaTicks > 0) {
                var velocity = player.getVelocity();
                double climbSpeed = s.lungeTicks > 0 ? 0.30 : 0.12;
                player.setVelocity(velocity.x, Math.max(velocity.y, climbSpeed), velocity.z);
                consumeStamina(s, s.lungeTicks > 0 ? 0.0f : (onRope ? 0.08f : 0.16f));
                s.lastStaminaUseTick = s.tick;
                s.climbingTicks++;
            } else {
                var velocity = player.getVelocity();
                player.setVelocity(velocity.x, Math.max(-0.22, velocity.y), velocity.z);
                s.climbingTicks = 0;
            }
        } else {
            s.climbingTicks = 0;
        }

        if (player.isSprinting() && !player.isOnGround()) {
            // Airborne sprinting is free in PEAK; only grounded sprinting spends stamina.
        } else if (player.isSprinting()) {
            consumeStamina(s, 0.08f);
            s.lastStaminaUseTick = s.tick;
        }

        // A lit Lantern is a temporary warmth source for nearby scouts.
        if (s.lanternTicks > 0 && s.tick % 20 == 0) {
            cureCold(player, 2.5f);
            for (PlayerEntity nearby : player.getWorld().getPlayers()) {
                if (nearby != player && nearby.squaredDistanceTo(player) <= 3.2 * 3.2) cureCold(nearby, 2.5f);
            }
        }

        // Cold and heat are environmental status effects; they cancel each other.
        if (s.tick % 20 == 0) {
            float biomeTemperature = player.getWorld().getBiome(player.getBlockPos()).value().getTemperature();
            if ((biomeTemperature < 0.15f || (player.getWorld().isRaining() && biomeTemperature < 0.8f)) && !nearCampfire) addCold(player, 0.5f);
            if (player.isOnFire() || player.isInLava()) addHeat(player, 1.0f);

        }

        // Hunger accumulates during an expedition; a campfire does not pause it.
        if (s.tick % 20 == 0) s.hunger = Math.min(100.0f, s.hunger + 0.05f);

        // Track falls separately: injury is not a generic penalty for every hit.
        if (!player.isOnGround()) {
            s.wasAirborne = true;
            s.maxFallDistance = Math.max(s.maxFallDistance, player.fallDistance);
        } else if (s.wasAirborne) {
            if (s.maxFallDistance >= 3.5f) {
                float fallInjury = Math.min(100.0f, (s.maxFallDistance - 3.0f) * 12.0f);
                s.injury = Math.min(100.0f, s.injury + fallInjury);
            }
            s.maxFallDistance = 0.0f;
            s.wasAirborne = false;
        }

        // PEAK weight is based on carried equipment mass, not occupied Minecraft slots.
        float carriedWeight = 0.0f;
        for (int i = 0; i < player.getInventory().size(); i++) {
            var stack = player.getInventory().getStack(i);
            if (!stack.isEmpty()) carriedWeight += itemWeight(stack) * stack.getCount();
        }
        s.weight = Math.max(0.0f, Math.min(100.0f, carriedWeight));

        if (s.pendingDrowsyDelay > 0) s.pendingDrowsyDelay--;
        else if (s.pendingDrowsy > 0.0f) {
            s.drowsy = Math.min(100.0f, s.drowsy + s.pendingDrowsy);
            s.drowsyDecayDelay = 200;
            s.pendingDrowsy = 0.0f;
        }
        if (s.pendingPoisonDelay > 0) s.pendingPoisonDelay--;
        else if (s.pendingPoison > 0.0f) {
            s.poison = Math.min(100.0f, s.poison + s.pendingPoison);
            s.poisonDecayDelay = 600;
            s.pendingPoison = 0.0f;
        }
        if (s.poisonDecayDelay > 0) s.poisonDecayDelay--;
        else if (s.tick % 20 == 0) s.poison = Math.max(0.0f, s.poison - 0.4f);
        if (s.coldDecayDelay > 0) s.coldDecayDelay--;
        else if (s.tick % 20 == 0) s.cold = Math.max(0.0f, s.cold - (nearCampfire ? 2.5f : 0.4f));
        if (s.heatDecayDelay > 0) s.heatDecayDelay--;
        else if (s.tick % 20 == 0) s.heat = Math.max(0.0f, s.heat - 1.3f);
        if (s.drowsyDecayDelay > 0) s.drowsyDecayDelay--;
        else if (s.drowsy > 0.0f && s.tick % 20 == 0) s.drowsy = Math.max(0.0f, s.drowsy - 1.5f);
        if (s.thornsDecayDelay > 0) s.thornsDecayDelay--;
        else if (s.thorns > 0.0f && s.tick % 20 == 0) s.thorns = Math.max(0.0f, s.thorns - 2.5f);
        if (s.sporesDecayDelay > 0) s.sporesDecayDelay--;
        else if (s.spores > 0.0f && s.tick % 20 == 0) s.spores = Math.max(0.0f, s.spores - 0.4f);

        s.stamina = Math.min(maxStamina(player), s.stamina);

        // Regeneration starts after a short pause and also works while safely grounded.
        if (player.isOnGround() || nearCampfire) {
            if (s.tick - s.lastStaminaUseTick >= 20) {
                float regen = nearCampfire ? 1.0f : 0.75f;
                s.stamina = Math.min(maxStamina(player), s.stamina + regen);
            }
        }

        if (s.tick % 40 == 0 && !client) {
            if (s.poison >= 25.0f) player.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 45, 0, true, false, true));
            if (s.drowsy >= 75.0f) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 45, 1, true, false, true));
            if (s.injury >= 75.0f) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 45, 0, true, false, true));
        }
    }

    private static float itemWeight(net.minecraft.item.ItemStack stack) {
        String id = net.minecraft.registry.Registries.ITEM.getId(stack.getItem()).getPath();
        return switch (id) {
            case "airline_food", "scout_cookies", "lantern", "cure_all", "pirate_compass", "passport" -> 5.0f;
            case "piton", "rope_spool", "trail_mix", "granola_bar", "honeycomb", "red_crispberry", "yellow_crispberry", "green_crispberry", "marshmallow", "hot_dog", "half_coconut", "scorchberry", "sports_drink", "energy_drink", "fortified_milk", "medicinal_root", "bandages", "antidote", "heat_pack" -> 2.5f;
            case "anti_rope_spool" -> -2.5f;
            case "first_aid_kit" -> 5.0f;
            default -> 0.0f;
        };
    }

    private static void consumeStamina(ScoutStats s, float amount) {
        if (amount <= 0.0f || s.infiniteStaminaTicks > 0) return;
        float remaining = amount;
        float fromMain = Math.min(s.stamina, remaining);
        s.stamina -= fromMain;
        remaining -= fromMain;
        if (remaining > 0.0f) s.bonusStamina = Math.max(0.0f, s.bonusStamina - remaining);
    }

    /** Shift-triggered PEAK-style vertical lunge. */
    private static void performClimbingLunge(PlayerEntity player) {
        if (player.isSpectator() || !player.isAlive() || player.isOnGround()
                || !(player.horizontalCollision || isNearRope(player))
                || !SERVER_CLIMB_HELD.getOrDefault(player.getUuid(), false)
                || player.isTouchingWater() || player.isInLava()) return;
        ScoutStats s = stats(player);
        if (s.lungeCooldown > 0 || ((s.stamina + s.bonusStamina) < 10.0f && s.infiniteStaminaTicks <= 0)) return;

        var velocity = player.getVelocity();
        double yaw = Math.toRadians(player.getYaw());
        double forwardX = -Math.sin(yaw) * 0.035;
        double forwardZ = Math.cos(yaw) * 0.035;
        player.setVelocity(velocity.x + forwardX, Math.max(velocity.y, 0.38), velocity.z + forwardZ);
        player.velocityModified = true;
        consumeStamina(s, 10.0f);
        s.lastStaminaUseTick = s.tick;
        s.lungeCooldown = 12;
        s.lungeTicks = 5;
        player.sendMessage(Text.translatable("message.peakmod.lunge"), true);
    }

    private static boolean isNearRope(PlayerEntity player) {
        BlockPos center = player.getBlockPos();
        for (BlockPos pos : BlockPos.iterate(center.add(-1, -1, -1), center.add(1, 1, 1))) {
            if (player.getWorld().getBlockState(pos).isOf(PeakMod.CLIMBING_ROPE_BLOCK)) return true;
        }
        return false;
    }

    private static boolean hasNearbyLitCampfire(PlayerEntity player) {
        BlockPos center = player.getBlockPos();
        for (BlockPos pos : BlockPos.iterate(center.add(-3, -2, -3), center.add(3, 2, 3))) {
            var state = player.getWorld().getBlockState(pos);
            if (state.getBlock() instanceof CampfireBlock && state.get(CampfireBlock.LIT)) return true;
        }
        return false;
    }

    public static final class ScoutStats {
        private float stamina = BASE_STAMINA;
        private float bonusStamina;
        private float hunger;
        private float injury;
        private float poison;
        private float cold;
        private float heat;
        private float drowsy;
        private float thorns;
        private float spores;
        private float weight;
        private float maxFallDistance;
        private int tick;
        private int climbingTicks;
        private int lungeCooldown;
        private int lungeTicks;
        private int poisonDecayDelay;
        private int coldDecayDelay;
        private int heatDecayDelay;
        private int thornsDecayDelay;
        private int sporesDecayDelay;
        private int pendingPoisonDelay;
        private float pendingPoison;
        private int pendingDrowsyDelay;
        private int drowsyDecayDelay;
        private float pendingDrowsy;
        private int infiniteStaminaTicks;
        private int lanternTicks;
        private int lastStaminaUseTick;
        private boolean wasAirborne;
        private String lastRegion = "";

        private float statusTotal() {
            return Math.min(200.0f, hunger + injury + poison + cold + heat + drowsy + thorns + spores + weight);
        }
        public float getStamina() { return stamina; }
        public float getBonusStamina() { return bonusStamina; }
        public float getHunger() { return hunger; }
        public float getInjury() { return injury; }
        public float getPoison() { return poison; }
        public float getCold() { return cold; }
        public float getHeat() { return heat; }
        public float getDrowsy() { return drowsy; }
        public float getThorns() { return thorns; }
        public float getSpores() { return spores; }
        public float getWeight() { return weight; }
        public boolean isClimbing() { return climbingTicks > 0; }
        public int getLungeCooldown() { return lungeCooldown; }
    }
}
