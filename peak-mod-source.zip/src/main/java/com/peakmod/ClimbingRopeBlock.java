package com.peakmod;

import net.minecraft.block.Block;

/** Non-solid climbable rope segment. */
public class ClimbingRopeBlock extends Block {
    public ClimbingRopeBlock(Settings settings) { super(settings); }
}
