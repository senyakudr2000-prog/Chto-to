package com.peakmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.BlockItem;
import net.minecraft.block.AbstractBlock;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.UseAction;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class PeakMod implements ModInitializer {
    public static final String MOD_ID = "peakmod";

    private static Identifier id(String path) { return Identifier.of(MOD_ID, path); }
    private static Item register(String name, Item item) { return Registry.register(Registries.ITEM, id(name), item); }

    private static FoodComponent foodComponent(int nutrition, float saturation) {
        return new FoodComponent.Builder().nutrition(nutrition).saturationModifier(saturation).alwaysEdible().build();
    }

    private static Item food(String name, int nutrition, float saturation, float hunger, float bonus,
                             float injury, float poisonHeal, float coldHeal, float heatHeal,
                             float thorns, float sporesHeal, float poisonAdd, int poisonDelay) {
        return register(name, new ScoutFoodItem(new Item.Settings().food(foodComponent(nutrition, saturation)),
                hunger, bonus, injury, poisonHeal, coldHeal, heatHeal, 0, thorns, sporesHeal,
                poisonAdd, poisonDelay, 0, 0));
    }

    public static final Item TRAIL_MIX = food("trail_mix", 2, 0.2f, 10, 10, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item GRANOLA_BAR = food("granola_bar", 3, 0.3f, 15, 20, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item SCOUT_COOKIES = register("scout_cookies", new ScoutFoodItem(
            new Item.Settings().food(foodComponent(2, 0.2f)).maxCount(4), 10, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0));
    public static final Item RED_CRISPBERRY = food("red_crispberry", 1, 0.1f, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item YELLOW_CRISPBERRY = food("yellow_crispberry", 1, 0.1f, 5, 10, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item GREEN_CRISPBERRY = food("green_crispberry", 1, 0.1f, 5, 0, 0, 0, 0, 0, 0, 0, 10, 40);
    public static final Item HONEYCOMB = food("honeycomb", 3, 0.3f, 10, 50, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item GOLD_PRICKLEBERRY = food("gold_prickleberry", 1, 0.1f, 15, 0, 10, 0, 0, 10, 10, 0, 0, 0);
    public static final Item AIRLINE_FOOD = food("airline_food", 4, 0.4f, 40, 40, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item MARSHMALLOW = food("marshmallow", 1, 0.1f, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item HOT_DOG = food("hot_dog", 3, 0.3f, 30, 20, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item HALF_COCONUT = food("half_coconut", 2, 0.2f, 10, 0, 0, 0, 0, 30, 0, 0, 0, 0);
    public static final Item SCORCHBERRY = register("scorchberry", new ScoutFoodItem(
            new Item.Settings().food(foodComponent(1, 0.1f)), 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0));
    public static final Item COOKED_TRAIL_MIX = food("cooked_trail_mix", 2, 0.2f, 20, 15, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_GRANOLA_BAR = food("cooked_granola_bar", 3, 0.3f, 30, 30, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_SCOUT_COOKIES = register("cooked_scout_cookies", new ScoutFoodItem(
            new Item.Settings().food(foodComponent(2, 0.2f)).maxCount(4), 20, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0));
    public static final Item COOKED_RED_CRISPBERRY = food("cooked_red_crispberry", 1, 0.1f, 10, 10, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_YELLOW_CRISPBERRY = food("cooked_yellow_crispberry", 1, 0.1f, 10, 15, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_GREEN_CRISPBERRY = food("cooked_green_crispberry", 1, 0.1f, 10, 10, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_HONEYCOMB = food("cooked_honeycomb", 3, 0.3f, 20, 75, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_GOLD_PRICKLEBERRY = food("cooked_gold_prickleberry", 1, 0.1f, 30, 10, 10, 0, 0, 10, 0, 0, 0, 0);
    public static final Item COOKED_AIRLINE_FOOD = food("cooked_airline_food", 4, 0.4f, 80, 60, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_MARSHMALLOW = food("cooked_marshmallow", 1, 0.1f, 30, 10, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_HOT_DOG = food("cooked_hot_dog", 3, 0.3f, 60, 30, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_HALF_COCONUT = food("cooked_half_coconut", 2, 0.2f, 20, 10, 0, 0, 0, 30, 0, 0, 0, 0);
    public static final Item COOKED_SCORCHBERRY = food("cooked_scorchberry", 1, 0.1f, 20, 10, 0, 0, 0, 0, 0, 0, 0, 0);
    public static final Item COOKED_MEDICINAL_ROOT = register("cooked_medicinal_root", new MedicalItem(new Item.Settings().maxCount(16), 10, 45, 45));

    public static final Item BIG_LOLLIPOP = register("big_lollipop", new BigLollipopItem(
            new Item.Settings().food(foodComponent(1, 0.1f))));
    public static final Item SPORTS_DRINK = register("sports_drink", new SupplyDrinkItem(
            new Item.Settings().maxCount(16), 30, 200, 0));
    public static final Item ENERGY_DRINK = register("energy_drink", new EnergyDrinkItem(new Item.Settings().maxCount(16)));
    public static final Item FORTIFIED_MILK = register("fortified_milk", new SupplyDrinkItem(
            new Item.Settings().maxCount(16), 0, 50, 5));

    public static final Item MEDICINAL_ROOT = register("medicinal_root", new MedicalItem(new Item.Settings().maxCount(16), 10, 25, 25));
    public static final Item BANDAGES = register("bandages", new MedicalItem(new Item.Settings().maxCount(16), 25, 0, 0));
    public static final Item FIRST_AID_KIT = register("first_aid_kit", new MedicalItem(new Item.Settings().maxCount(8), 35, 35, 0));
    public static final Item ANTIDOTE = register("antidote", new AntidoteItem(new Item.Settings().maxCount(16)));
    public static final Item CURE_ALL = register("cure_all", new CureAllItem(new Item.Settings().maxCount(3)));
    public static final Item HEAT_PACK = register("heat_pack", new HeatPackItem(new Item.Settings().maxCount(8)));
    public static final Item GUIDEBOOK = register("guidebook", new GuidebookItem(new Item.Settings().maxCount(1)));
    public static final Item LANTERN = register("lantern", new LanternItem(new Item.Settings().maxCount(1)));
    public static final PitonBlock PITON_BLOCK = Registry.register(Registries.BLOCK, id("piton_block"),
            new PitonBlock(AbstractBlock.Settings.create().strength(0.5f).sounds(BlockSoundGroup.METAL).nonOpaque().noCollision()));
    public static final Item PITON = register("piton", new BlockItem(PITON_BLOCK, new Item.Settings().maxCount(8)));
    public static final ClimbingRopeBlock CLIMBING_ROPE_BLOCK = Registry.register(Registries.BLOCK, id("climbing_rope_block"),
            new ClimbingRopeBlock(AbstractBlock.Settings.create().strength(0.2f).sounds(BlockSoundGroup.WOOL).nonOpaque().noCollision().breakInstantly()));
    public static final Item ROPE_SPOOL = register("rope_spool", new RopeSpoolItem(new Item.Settings().maxCount(4), false));
    public static final Item ANTI_ROPE_SPOOL = register("anti_rope_spool", new RopeSpoolItem(new Item.Settings().maxCount(4), true));
    public static final Item PIRATE_COMPASS = register("pirate_compass", new PirateCompassItem(new Item.Settings().maxCount(1)));
    public static final Item PASSPORT = register("passport", new PassportItem(new Item.Settings().maxCount(1)));
    public static final BoardingBlock BOARDING_BLOCK = Registry.register(Registries.BLOCK, id("boarding_block"),
            new BoardingBlock(AbstractBlock.Settings.create().strength(4.0f).sounds(BlockSoundGroup.METAL).luminance(state -> 8)));

    @Override
    public void onInitialize() {
        PeakMechanics.initialize();
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> server.execute(() -> {
            var player = handler.player;
            if (!player.getCommandTags().contains("peakmod_airport_spawned")) {
                player.addCommandTag("peakmod_airport_spawned");
                ExpeditionWorld.buildAirport(player);
                if (!player.getInventory().contains(new net.minecraft.item.ItemStack(PASSPORT))) {
                    player.getInventory().insertStack(new net.minecraft.item.ItemStack(PASSPORT));
                }
            }
        }));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(entries -> {
            entries.add(TRAIL_MIX); entries.add(GRANOLA_BAR); entries.add(SCOUT_COOKIES);
            entries.add(RED_CRISPBERRY); entries.add(YELLOW_CRISPBERRY); entries.add(GREEN_CRISPBERRY);
            entries.add(HONEYCOMB); entries.add(GOLD_PRICKLEBERRY); entries.add(AIRLINE_FOOD);
            entries.add(MARSHMALLOW); entries.add(HOT_DOG); entries.add(HALF_COCONUT); entries.add(SCORCHBERRY);
            entries.add(COOKED_TRAIL_MIX); entries.add(COOKED_GRANOLA_BAR); entries.add(COOKED_SCOUT_COOKIES);
            entries.add(COOKED_RED_CRISPBERRY); entries.add(COOKED_YELLOW_CRISPBERRY); entries.add(COOKED_GREEN_CRISPBERRY);
            entries.add(COOKED_HONEYCOMB); entries.add(COOKED_GOLD_PRICKLEBERRY); entries.add(COOKED_AIRLINE_FOOD);
            entries.add(COOKED_MARSHMALLOW); entries.add(COOKED_HOT_DOG); entries.add(COOKED_HALF_COCONUT); entries.add(COOKED_SCORCHBERRY);
            entries.add(COOKED_MEDICINAL_ROOT);
            entries.add(BIG_LOLLIPOP); entries.add(SPORTS_DRINK); entries.add(ENERGY_DRINK); entries.add(FORTIFIED_MILK);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(MEDICINAL_ROOT); entries.add(BANDAGES); entries.add(FIRST_AID_KIT);
            entries.add(ANTIDOTE); entries.add(CURE_ALL); entries.add(HEAT_PACK); entries.add(LANTERN); entries.add(GUIDEBOOK);
            entries.add(PITON); entries.add(ROPE_SPOOL); entries.add(ANTI_ROPE_SPOOL); entries.add(PIRATE_COMPASS); entries.add(PASSPORT);
        });
    }

    private static class ScoutFoodItem extends Item {
        private final float hunger, bonus, injury, poisonHeal, coldHeal, heatHeal, drowsyHeal;
        private final float thorns, sporesHeal, poisonAdd;
        private final int poisonDelay;
        private final float heatAdd;
        private final int drowsyDelay;

        ScoutFoodItem(Settings settings, float hunger, float bonus, float injury, float poisonHeal,
                      float coldHeal, float heatHeal, float drowsyHeal, float thorns, float sporesHeal,
                      float poisonAdd, int poisonDelay, float heatAdd, int drowsyDelay) {
            super(settings);
            this.hunger = hunger; this.bonus = bonus; this.injury = injury; this.poisonHeal = poisonHeal;
            this.coldHeal = coldHeal; this.heatHeal = heatHeal; this.drowsyHeal = drowsyHeal;
            this.thorns = thorns; this.sporesHeal = sporesHeal; this.poisonAdd = poisonAdd;
            this.poisonDelay = poisonDelay; this.heatAdd = heatAdd; this.drowsyDelay = drowsyDelay;
        }
        @Override public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            ItemStack result = super.finishUsing(stack, world, user);
            if (user instanceof PlayerEntity player) {
                PeakMechanics.consumeFood(player, hunger, bonus, injury, poisonHeal, coldHeal, heatHeal,
                        drowsyHeal, thorns, sporesHeal);
                if (poisonAdd > 0) {
                    if (poisonDelay > 0) PeakMechanics.schedulePoison(player, poisonAdd, poisonDelay);
                    else PeakMechanics.addPoison(player, poisonAdd);
                }
                if (heatAdd > 0) PeakMechanics.addHeat(player, heatAdd);
                if (drowsyDelay > 0) PeakMechanics.scheduleDrowsy(player, 32.5f, drowsyDelay);
            }
            return result;
        }
    }

    private static class BigLollipopItem extends Item {
        BigLollipopItem(Settings settings) { super(settings); }
        @Override public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            ItemStack result = super.finishUsing(stack, world, user);
            if (user instanceof PlayerEntity player) {
                PeakMechanics.consumeFood(player, 5, 0, 0, 0, 0, 0, 0, 0, 0);
                PeakMechanics.grantInfiniteStamina(player, 220);
                PeakMechanics.scheduleDrowsy(player, 32.5f, 200);
            }
            return result;
        }
    }

    private static class MedicalItem extends Item {
        private final float injury, poison, spores;
        MedicalItem(Settings settings, float injury, float poison, float spores) {
            super(settings); this.injury = injury; this.poison = poison; this.spores = spores;
        }
        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack stack = user.getStackInHand(hand);
            PeakMechanics.consumeFood(user, 5, 0, injury, poison, 0, 0, 0, 0, spores);
            if (!world.isClient()) {
                if (poison > 0) user.removeStatusEffect(StatusEffects.POISON);
                world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_HONEY_BOTTLE_DRINK, SoundCategory.PLAYERS, 0.7f, 1.1f);
                if (!user.getAbilities().creativeMode) stack.decrement(1);
            }
            return TypedActionResult.success(stack, world.isClient());
        }
    }

    private static class AntidoteItem extends Item {
        AntidoteItem(Settings settings) { super(settings); }
        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack stack = user.getStackInHand(hand);
            PeakMechanics.curePoison(user, 100);
            PeakMechanics.cureHeat(user, 30);
            if (!world.isClient()) {
                user.removeStatusEffect(StatusEffects.POISON);
                if (!user.getAbilities().creativeMode) stack.decrement(1);
                world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_HONEY_BOTTLE_DRINK, SoundCategory.PLAYERS, 0.8f, 1.0f);
            }
            return TypedActionResult.success(stack, world.isClient());
        }
    }

    private static class CureAllItem extends Item {
        CureAllItem(Settings settings) { super(settings); }
        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack stack = user.getStackInHand(hand);
            PeakMechanics.cleanse(user);
            if (!world.isClient()) {
                user.removeStatusEffect(StatusEffects.POISON);
                user.removeStatusEffect(StatusEffects.SLOWNESS);
                user.removeStatusEffect(StatusEffects.WEAKNESS);
                if (!user.getAbilities().creativeMode) stack.decrement(1);
                world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_HONEY_BOTTLE_DRINK, SoundCategory.PLAYERS, 0.8f, 1.2f);
            }
            return TypedActionResult.success(stack, world.isClient());
        }
    }

    private static class HeatPackItem extends Item {
        HeatPackItem(Settings settings) { super(settings); }
        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack stack = user.getStackInHand(hand);
            PeakMechanics.cureCold(user, 50);
            if (!world.isClient()) {
                if (!user.getAbilities().creativeMode) stack.decrement(1);
                world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 0.5f, 1.0f);
            }
            return TypedActionResult.success(stack, world.isClient());
        }
    }

    private static class SupplyDrinkItem extends Item {
        private final float bonus, heat, hunger;
        SupplyDrinkItem(Settings settings, float bonus, float heat, float hunger) {
            super(settings); this.bonus = bonus; this.heat = heat; this.hunger = hunger;
        }
        @Override public UseAction getUseAction(ItemStack stack) { return UseAction.DRINK; }
        @Override public int getMaxUseTime(ItemStack stack) { return 32; }
        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            user.setCurrentHand(hand);
            return TypedActionResult.consume(user.getStackInHand(hand));
        }
        @Override public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (user instanceof PlayerEntity player) {
                PeakMechanics.consumeFood(player, hunger, bonus, 0, 0, 0, heat, 0, 0, 0);
                if (!player.getAbilities().creativeMode) stack.decrement(1);
            }
            return stack;
        }
    }

    private static class EnergyDrinkItem extends Item {
        EnergyDrinkItem(Settings settings) { super(settings); }
        @Override public UseAction getUseAction(ItemStack stack) { return UseAction.DRINK; }
        @Override public int getMaxUseTime(ItemStack stack) { return 32; }
        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            user.setCurrentHand(hand);
            return TypedActionResult.consume(user.getStackInHand(hand));
        }
        @Override public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (user instanceof PlayerEntity player) {
                PeakMechanics.cureDrowsy(player, 100);
                PeakMechanics.cureHeat(player, 30);
                PeakMechanics.scheduleDrowsy(player, 25, 20 * 12);
                if (!world.isClient()) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 12, 0));
                    if (!player.getAbilities().creativeMode) stack.decrement(1);
                }
            }
            return stack;
        }
    }

    private static class PirateCompassItem extends Item {
        PirateCompassItem(Settings settings) { super(settings); }
        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            if (!world.isClient()) {
                net.minecraft.util.math.BlockPos center = user.getBlockPos();
                net.minecraft.util.math.BlockPos nearest = null;
                double best = Double.MAX_VALUE;
                for (net.minecraft.util.math.BlockPos pos : net.minecraft.util.math.BlockPos.iterate(
                        center.add(-32, -8, -32), center.add(32, 8, 32))) {
                    var state = world.getBlockState(pos);
                    if (state.isOf(Blocks.CHEST) || state.isOf(Blocks.TRAPPED_CHEST) || state.isOf(Blocks.BARREL)) {
                        double distance = user.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                        if (distance < best) { best = distance; nearest = pos.toImmutable(); }
                    }
                }
                if (nearest == null) user.sendMessage(Text.translatable("message.peakmod.compass_none"), true);
                else user.sendMessage(Text.translatable("message.peakmod.compass_target", nearest.getX(), nearest.getY(), nearest.getZ(), Math.round(Math.sqrt(best))), true);
                world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_COMPASS_LOCK, SoundCategory.PLAYERS, 0.6f, 1.0f);
            }
            return TypedActionResult.success(user.getStackInHand(hand), world.isClient());
        }
    }

    private static class LanternItem extends Item {
        LanternItem(Settings settings) { super(settings); }
        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            PeakMechanics.activateLantern(user, 20 * 60);
            if (!world.isClient()) {
                user.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 20 * 60, 0, true, false, true));
                world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_FLINTANDSTEEL_USE, SoundCategory.PLAYERS, 0.5f, 1.0f);
            }
            return TypedActionResult.success(user.getStackInHand(hand), world.isClient());
        }
    }

    private static class GuidebookItem extends Item {
        GuidebookItem(Settings settings) { super(settings); }
        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            if (!world.isClient()) user.sendMessage(Text.translatable("message.peakmod.guide"), false);
            return TypedActionResult.success(user.getStackInHand(hand), world.isClient());
        }
    }
}
