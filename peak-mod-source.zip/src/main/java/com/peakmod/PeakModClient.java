package com.peakmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class PeakModClient implements ClientModInitializer {
    private static KeyBinding climbKey;
    private static KeyBinding lungeKey;
    private boolean lastClimbState;

    @Override
    public void onInitializeClient() {
        climbKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.peakmod.climb", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT,
                "category.peakmod.controls"));
        lungeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.peakmod.lunge", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_SHIFT,
                "category.peakmod.controls"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null) PeakMechanics.tickClientPlayer(client.player);
            if (client.player == null || client.getNetworkHandler() == null) {
                lastClimbState = false;
                return;
            }
            boolean climbing = climbKey.isPressed();
            PeakMechanics.setClientClimbHeld(client.player, climbing);
            if (climbing != lastClimbState) {
                ClientPlayNetworking.send(PeakMechanics.CLIMB_PACKET, PacketByteBufs.create().writeBoolean(climbing));
                lastClimbState = climbing;
            }
            while (lungeKey.wasPressed()) {
                PeakMechanics.predictClientLunge(client.player);
                ClientPlayNetworking.send(PeakMechanics.LUNGE_PACKET, PacketByteBufs.empty());
            }
        });
        HudRenderCallback.EVENT.register((context, tickCounter) -> renderScoutHud(context));
    }

    private static void renderScoutHud(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;
        int x = 10;
        int y = context.getScaledWindowHeight() - 132;
        int width = 92;
        PeakMechanics.ScoutStats stats = PeakMechanics.stats(client.player);
        drawBar(context, x, y, width, 6, stats.getStamina(), PeakMechanics.maxStamina(client.player), 0xFF55D6A0, "hud.peakmod.stamina");
        drawBar(context, x, y + 9, width, 4, stats.getBonusStamina(), 100, 0xFFE8D65A, "hud.peakmod.bonus");
        drawBar(context, x, y + 17, width, 4, stats.getHunger(), 100, 0xFFE5B85C, "hud.peakmod.hunger");
        drawBar(context, x, y + 25, width, 4, stats.getInjury(), 100, 0xFFE36B64, "hud.peakmod.injury");
        drawBar(context, x, y + 33, width, 4, stats.getPoison(), 100, 0xFF9B65C9, "hud.peakmod.poison");
        drawBar(context, x, y + 41, width, 4, stats.getCold(), 100, 0xFF6FC9E8, "hud.peakmod.cold");
        drawBar(context, x, y + 49, width, 4, stats.getHeat(), 100, 0xFFE58A4F, "hud.peakmod.heat");
        drawBar(context, x, y + 57, width, 4, stats.getDrowsy(), 100, 0xFF8C91D9, "hud.peakmod.drowsy");
        drawBar(context, x, y + 65, width, 4, stats.getThorns(), 100, 0xFF91A95B, "hud.peakmod.thorns");
        drawBar(context, x, y + 73, width, 4, stats.getSpores(), 100, 0xFF7B9A70, "hud.peakmod.spores");
        drawBar(context, x, y + 81, width, 4, stats.getWeight(), 100, 0xFFB6A18A, "hud.peakmod.weight");
        if (stats.isClimbing()) {
            context.drawTextWithShadow(client.textRenderer, Text.translatable("hud.peakmod.climbing"), x, y - 11, 0xFF8ED7FF);
        }
    }

    private static void drawBar(DrawContext context, int x, int y, int width, int height,
                                float value, float max, int color, String translationKey) {
        float safeMax = Math.max(1.0f, max);
        int filled = Math.max(0, Math.min(width, Math.round(width * value / safeMax)));
        context.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xAA101820);
        context.fill(x, y, x + width, y + height, 0xFF303942);
        if (filled > 0) context.fill(x, y, x + filled, y + height, color);
        Text label = Text.translatable(translationKey).append(" " + Math.round(value));
        context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer,
                label, x + width + 4, y - 1, 0xFFEAF1F5);
    }
}
